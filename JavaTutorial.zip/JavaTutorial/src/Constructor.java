class Machine{

    private String name;
     public Machine() {

         System.out.println("Constructor running");
         name = "Mahdy";
     }

    public Machine (String name){
        System.out.println("Second Constructor");
        this.name=name;
    }

}


public class Constructor {
    public static void main(String[] args) {
        Machine machine1= new Machine();
        new Machine();
        Machine machine2=new Machine("Hasan");

    }

}
