import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

// Demo 1 e jodi file na thake tahole amader run time e error dekhabe j file nai
/*class Demo1{
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("file.txt");
        FileReader fr = new FileReader(file);
    }

}*/
//demo2 te jodi file na thake tahole error dekabe kintu amra chaile oita error dekabe na eta try korbe catch korte code na
// paile bolbe j file not found othova amara ja chai just catch method likte hobe
/*class Demo2{
    public static void main(String[] args) {
        File file=new File("test.txt");
        FileReader fileReader;

        {
            try {
                fileReader = new FileReader(file);
            } catch (FileNotFoundException e) {
                System.out.println("FIle not Found");
            }
        }
    }
    }*/
//HandelException class e amra method er modde file exception declare kore main function e call korle amra eivabe korte pari
/*class HandelingException{
    public static void main(String[] args) {
        try {
            openFile();
        } catch (FileNotFoundException e) {
            System.out.println("File Cant Found");
        }
    }

    public static void openFile() throws FileNotFoundException {
        File file = new File("file.txt");
        FileReader fr = new FileReader(file);
    }
}*/


