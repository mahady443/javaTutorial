package TransiantKeyword;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WriteObject {
    public static void main(String[] args) {
        Person mahady = new Person(10,"Mahady");
        Person hasan = new Person(1,"Hasan");
        System.out.println(mahady);
        System.out.println(hasan);

        try(FileOutputStream fs = new FileOutputStream("pepole.bin")){
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(mahady);
            os.writeObject(hasan);
            os.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
