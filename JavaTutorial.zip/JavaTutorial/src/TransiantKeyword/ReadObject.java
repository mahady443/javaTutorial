package TransiantKeyword;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadObject {
    public static void main(String[] args) {
        System.out.println("Reading Object");
        try (FileInputStream fi = new FileInputStream("pepole.bin")){
            ObjectInputStream oi = new ObjectInputStream(fi);
            Person person1= (Person) oi.readObject();
            Person person2 = (Person)oi.readObject();
            oi.close();

            System.out.println(person1);
            System.out.println(person2);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
