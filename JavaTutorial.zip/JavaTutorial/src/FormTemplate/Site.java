package FormTemplate;

public class Site {
    double units;
    double base;
    double tax;


    public static void main(String[] args) {
        Residential r1= new Residential();
        r1.getBillAmmount(20,20);

    }
}

