package FormTemplate;

public class Residential extends Site {

    public double getBaseAmmount(){
        double base = units*0.5;
        return base ;

    }

    public double getTaxAMmount(){
        tax = 0.5 * base;
        return tax;
    }
    public double getBillAmmount(double base, double tax){
        return base+tax;
    }
}
