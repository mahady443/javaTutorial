package com.mahady.inheritence;

public class Car extends Inheritence {
    @Override
    public void start(){
        System.out.println("Car Start");
    }
    public void windShiled(){
        System.out.println("Wipe Machine");
    }
    public void showinfo(){
       // System.out.println(name);
    }
}
