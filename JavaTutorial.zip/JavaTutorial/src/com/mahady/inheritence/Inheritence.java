package com.mahady.inheritence;

public class Inheritence {


    private String name;
    public void start(){
        System.out.println("Machine Start");
    }

    public void stop(){
        System.out.println("Machine Stopped");
    }
}
