package com.mahady.inheritence;

public class InheritenceTest {
     public static void main(String[] args) {
          Inheritence ob = new Inheritence();
          ob.start();
          ob.stop();
          Car ob1 = new Car();
          ob1.start();
          ob1.windShiled();
          ob1.stop();
     }

}
