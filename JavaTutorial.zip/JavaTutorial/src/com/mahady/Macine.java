package com.mahady;

public class Macine {
    public void strat (){
        System.out.println("Machine is Start");
    }
}
