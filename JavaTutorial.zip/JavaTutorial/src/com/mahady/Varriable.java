package com.mahady;

public class Varriable {
    public static void main(String[] args) {
        byte mybyte= 127;
        int myint = 3000;
        long mylong= 12000;
        short myshort = 12;

        char mychar = 'm';
        double mydouble = 3000.55444;
        float mufloat = 10.241f;
        boolean myboolean = true;
        String mystring = "mahgadh 4544";

        System.out.println(mufloat);
        System.out.println(myboolean);
        System.out.println(mychar);
        System.out.println(mybyte);
        System.out.println(mylong);
        System.out.println(mydouble);
        System.out.println(myint);
        System.out.println(myshort);
        System.out.println(mystring);

    }
}
