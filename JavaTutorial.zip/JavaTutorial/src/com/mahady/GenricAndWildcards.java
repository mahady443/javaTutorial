package com.mahady;

public class GenricAndWildcards {
    public static void main(String[] args) {

    }
}
