package com.mahady;

public class RunTimeAndCheckedException {
}
