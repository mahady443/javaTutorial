package com.mahady;

public class AccessModifier {
    public static void main(String[] args) {
        HelloWorld ob2= new HelloWorld();
        ob2.NonStaticTest();

    }

}
