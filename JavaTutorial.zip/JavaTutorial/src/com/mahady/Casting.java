package com.mahady;

public class Casting {
    public static void main(String[] args) {
       int value1 = 36;
       double value2 = 333.66;
       float value=33.5f;

       value1 = (int)value2;// (int) cast type
        System.out.println(value1);
    }
}
