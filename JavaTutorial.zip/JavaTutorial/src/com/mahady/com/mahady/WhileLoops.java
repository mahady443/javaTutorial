package com.mahady.com.mahady;

public class WhileLoops {
    public static void main(String[] args) {
        int value = 0 ;

        while (value<10){
            System.out.println(" hello" +value);
            value = value+1;
        }



    }
}
