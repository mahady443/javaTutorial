package com.mahady.com.mahady.polymorphism;

public class Tree extends Plant {
    public void grow (){
        System.out.println("Teree grow");
    }
    public void Leaf(){
        System.out.println("leaf grow");
    }
}
