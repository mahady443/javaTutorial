package com.mahady.com.mahady.polymorphism;

public class Plant {

    public void grow (){
        System.out.println("Plant Growing");
    }
}
