package com.mahady.com.mahady;

abstract public class shape {
    abstract float area();

}
