package com.mahady.com.mahady.Interface;

public interface Info {
    public void showinfo();

    }

