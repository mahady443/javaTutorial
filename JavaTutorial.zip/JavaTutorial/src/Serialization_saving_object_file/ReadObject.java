package Serialization_saving_object_file;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadObject {
    public static void main(String[] args) {
        System.out.println("Reading Object");
        try (FileInputStream fi = new FileInputStream("test.ser")){
            ObjectInputStream oi = new ObjectInputStream(fi);
            Person person= (Person) oi.readObject();

            System.out.println(person);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
