package Serialization_saving_object_file;

import java.io.Serializable;

// serialize korar jonno implements korte hoi oi class k Serializable class er shate eta java pre-define interface class
public class Person implements Serializable {
    private int id;
    private String name;
    public Person(int id , String name){
        this.id= id;
        this.name= name;
    }

    @Override
    public String toString(){
        return "Person[ id= "+ id +", name = " + name +"]";
    }
}
