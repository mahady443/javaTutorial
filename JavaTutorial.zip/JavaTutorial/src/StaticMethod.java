class Thing{
    public  String name;
    public static String description;
    public final static int LUCKY_NUM = 7;
    public static int count = 0;
    public int id;
    public Thing(){
        id= count;
        count++;
    }

    public void showName(){
        System.out.println("object id:"+id +name);
    }
    public static void showDescription(){
        System.out.println(description);
    }
}




public class StaticMethod {
    public static void main(String[] args) {

        Thing.description="I ama Student";
        Thing.showDescription();
        System.out.println("before creating object count is : " + Thing.count);
        Thing thing1= new Thing();
        Thing thing2= new Thing();
        System.out.println("After creating object count is : " + Thing.count);



        thing1.name="Mahady";
        thing2.name="Hasan";

        thing1.showName();
        thing2.showName();

        System.out.println(Math.PI);
        System.out.println(Thing.LUCKY_NUM);
    }
}
